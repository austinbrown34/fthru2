// Global Config Vars
FTHRU_SETTINGS = {
  API_HOSTNAME: "development.fthru.cogni.design",
  EDMUNDS_API_KEY: '6gkv78s45kfx5cbgcf4mq5ae'
}
